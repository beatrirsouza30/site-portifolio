function hello(){
    alert("Hello Word !!!")
}
function nao_clique(){
    document.getElementById("resposta").innerHTML="poxa eu disse para não clicar ai !!!:(";
}